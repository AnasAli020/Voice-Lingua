import sys;

#sys.argv[1]



print('python working');
sys.stdout.flush();